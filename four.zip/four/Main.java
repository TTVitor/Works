package four;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	
	 public static void main(String[] args) {
	     
	 //Scanner scan = new Scanner(System.in);
	 AmericanFootball afootball = new AmericanFootball();
	 Soccer soccer = new Soccer();
	 Basketball basket = new Basketball();
	
	 Event nfl = new Event(); 
	 Event champ = new Event();
	 
	 nfl.addTeam(new Team("New England Patriots", afootball));
	 champ.addTeam(new Team("Manchester United", soccer));
	 
	 Player eldeman = new Player(afootball);
	 Player lloris = new Player(soccer);
	 
	 nfl.getTeamByName("New England Patriots").addPlayer(eldeman);
	}

}