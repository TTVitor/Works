package four;

public class Person {
	private String name;
	private String email;
	private String cpf;
	private String endereco;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public void printPerson() {
		System.out.println("---------PEOPLE DATA---------");
		System.out.println("Name: " +getName());
		System.out.println("Email: " +getEmail());
		System.out.println("CPF: " +getCpf());
		System.out.println("Endere�o: " +getEndereco());
	}
}

