package four;

public class Player extends Person {
	private Sport sport;
	
	public Player(Sport sport) {
		super();
		this.sport = sport;
	}

	public Sport getSport() {
		return sport;
	}

	public void setSport(Sport sport) {
		this.sport = sport;
	}
	
	public void printPlayer() {
		super.printPerson();
		System.out.println("Esporte do jogador: " +getSport());
	}
}
