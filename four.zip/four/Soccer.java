package four;

public class Soccer extends Sport {
	
	public Soccer() {
		super();
	}
	
	public void printData() {
		
	}

}
